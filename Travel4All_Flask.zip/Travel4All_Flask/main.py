from flask import Flask, render_template, request
import requests
import json
from amadeus import Client

app = Flask(__name__)

amadeus = Client(
    client_id='N41sZfq8FmoigGxFpX4S60rgbVRy4uJM',
    client_secret='Kiieanv4cCeaIhRT'
)

@app.route('/search',methods=['POST'])
def flight_search():
	t1=request.form['FROM']
	t2=request.form['TO']
	t3=request.form['DATE']
	t4=request.form['ADULTS']
	

	response = amadeus.shopping.flight_offers_search.get(originLocationCode=t1, destinationLocationCode=t2, departureDate=t3, adults=t4)
	return render_template('searching.html', data=response.data)

@app.route('/')
def index():
	return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)